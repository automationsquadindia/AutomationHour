with open("hello.txt","wt") as f:
    f.write("Hello RPA Developers")